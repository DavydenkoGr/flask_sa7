from flask import Flask, render_template, redirect
from data import db_session
from data.users6 import User
from data.jobs6 import Jobs
import datetime

app = Flask(__name__)


@app.route("/")
def index():
    team_leaders = list()
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    for job in jobs:
        user = db_sess.query(User).filter(User.id == job.team_leader).first()
        team_leaders.append(f'{user.surname} {user.name}')
    return render_template("list_of_tables.html", jobs=jobs, team_leaders=team_leaders)


def main():
    db_session.global_init("db/colonists.db")
    db_sess = db_session.create_session()

    user = User()
    user.surname = 'Scott'
    user.name = 'Ridley'
    user.age = 21
    user.position = 'capitan'
    user.speciality = 'research engineer'
    user.address = 'module_1'
    user.email = 'scott_chief@mars.org'
    db_sess.add(user)

    user = User()
    user.surname = 'Weir'
    user.name = 'Endy'
    user.age = 26
    user.position = "captain's mate"
    user.speciality = 'pilot'
    user.address = 'module_2'
    user.email = 'uir_endy@mars.org'
    db_sess.add(user)

    user = User()
    user.surname = 'Whitney'
    user.name = 'Mark'
    user.age = 29
    user.position = "crew member"
    user.speciality = 'radiation protection specialist'
    user.address = 'module_3'
    user.email = 'whitney_mark@mars.org'
    db_sess.add(user)

    user = User()
    user.surname = 'Sanders'
    user.name = 'Teddy'
    user.age = 23
    user.position = "crew member"
    user.speciality = 'engineer'
    user.address = 'module_4'
    user.email = 'kapoor_wenkata@mars.org'
    db_sess.add(user)

    db_sess.commit()

    job = Jobs()
    job.team_leader = 1
    job.job = 'Deployment of residential modules 1 and 2'
    job.work_size = 15
    job.collaborators = '2, 3'
    job.start_date = datetime.datetime.now()
    job.is_finished = False
    db_sess.add(job)

    job = Jobs()
    job.team_leader = 2
    job.job = 'Exploration of minerals resources'
    job.work_size = 15
    job.collaborators = '4, 3'
    job.start_date = datetime.datetime.now()
    job.is_finished = False
    db_sess.add(job)

    job = Jobs()
    job.team_leader = 3
    job.job = 'Development of a management system'
    job.work_size = 25
    job.collaborators = '5'
    job.start_date = datetime.datetime.now()
    job.is_finished = False
    db_sess.add(job)
    db_sess.commit()
    app.run()


if __name__ == '__main__':
    main()